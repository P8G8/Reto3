package com.reto3.reto3p8g8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto3p8g8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
